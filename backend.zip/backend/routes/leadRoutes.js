const express = require("express");
const router = express.Router();
console.log("leadRoutes.js loaded");

const {
  createLead,
  getLeads,
} = require("../controllers/leadController");

router.post("/", createLead);
router.get("/", (req, res) => {
  res.send("Lead Route Working");
});

module.exports = router;