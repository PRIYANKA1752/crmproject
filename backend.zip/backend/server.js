const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const leadRoutes = require("./routes/leadRoutes");
console.log("Lead Routes Loaded");


dotenv.config();

console.log("MONGO_URI =", process.env.MONGO_URI);

connectDB();

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/leads", leadRoutes);


app.get("/", (req, res) => {
  res.send("CRM Backend Running");
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});